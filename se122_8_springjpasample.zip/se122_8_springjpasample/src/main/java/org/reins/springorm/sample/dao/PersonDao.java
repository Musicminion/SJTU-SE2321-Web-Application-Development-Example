package org.reins.springorm.sample.dao;

import org.reins.springorm.sample.entity.Person;

import java.util.List;

/**
 * Created by chenhaopeng on 2019/5/2.
 */
public interface PersonDao {
    Person findOne(Integer id);

    List<Person> findByAge(Integer age);
}
