package org.reins.springorm.sample.entity;

import com.fasterxml.jackson.annotation.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenhaopeng on 2019/5/2.
 */
@Entity
@Table(name = "persons", schema = "ormsample")
@JsonIgnoreProperties(value = {"handler","hibernateLazyInitializer","fieldHandler"})
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "personId")
public class Person {
    private int personId;
    private Integer age;
    private String firstname;
    private String lastname;

    @Id
    @Column(name = "id")
    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    @Basic
    @Column(name = "age")
    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Basic
    @Column(name = "firstname")
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    @Basic
    @Column(name = "lastname")
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Person person = (Person) o;

        if (personId != person.personId) return false;
        if (age != null ? !age.equals(person.age) : person.age != null) return false;
        if (firstname != null ? !firstname.equals(person.firstname) : person.firstname != null) return false;
        if (lastname != null ? !lastname.equals(person.lastname) : person.lastname != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = personId;
        result = 31 * result + (age != null ? age.hashCode() : 0);
        result = 31 * result + (firstname != null ? firstname.hashCode() : 0);
        result = 31 * result + (lastname != null ? lastname.hashCode() : 0);
        return result;
    }

    private List<Event> activities;

    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "participants")
    public List<Event> getActivities() {
        return activities;
    }

    public void setActivities(List<Event> activities) {
        this.activities = activities;
    }

    private List<String> emails = new ArrayList<String>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable( name="PERSON_EMAIL",
            joinColumns = { @JoinColumn(name = "person_id", referencedColumnName = "id")})
    @Column(name="EMAIL_ADDRESS")
    public List<String> getEmails() {
        return emails;
    }

    public void setEmails(List<String> emails) {
        this.emails = emails;
    }

}
