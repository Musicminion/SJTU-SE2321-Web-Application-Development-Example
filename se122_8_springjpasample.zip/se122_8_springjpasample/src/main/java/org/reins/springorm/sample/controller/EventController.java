package org.reins.springorm.sample.controller;

import org.reins.springorm.sample.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.reins.springorm.sample.entity.Event;

import java.util.List;

@RestController
public class EventController {

    @Autowired
    private EventService eventService;

    @GetMapping(value = "/findEvent/{id}")
    public Event findEvent(@PathVariable("id") Integer id) {
        System.out.println("Searching Event: " + id);
        return eventService.findEventById(id);
    }

    @GetMapping(value = "/findByTitle/{title}")
    public List<Event> findEventByTitle(@PathVariable("title") String title) {
        System.out.println("Searching Event: " + title);
        return eventService.findByTitle(title);
    }
}
