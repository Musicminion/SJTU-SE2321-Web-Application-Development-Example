package org.reins.springorm.sample.daoimpl;

import org.reins.springorm.sample.dao.PersonDao;
import org.reins.springorm.sample.entity.Person;
import org.reins.springorm.sample.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by chenhaopeng on 2019/5/2.
 */
@Repository
public class PersonDaoImpl implements PersonDao {
        @Autowired
        private PersonRepository personRepository;


        @Override
        public Person findOne(Integer id) {
            return personRepository.getOne(id);
        }

        public List<Person> findByAge(Integer age){return personRepository.findByAge(age); }

}
