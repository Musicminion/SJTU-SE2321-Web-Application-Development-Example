package org.reins.springorm.sample.service;

import org.reins.springorm.sample.entity.Event;

import java.util.List;

/**
 * Created by chenhaopeng on 2019/5/2.
 */
public interface EventService {
    Event findEventById(Integer id);

    List<Event> findByTitle(String title);
}
