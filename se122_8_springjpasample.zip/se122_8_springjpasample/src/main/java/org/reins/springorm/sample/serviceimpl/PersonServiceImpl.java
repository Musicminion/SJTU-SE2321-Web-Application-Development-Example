package org.reins.springorm.sample.serviceimpl;

import org.reins.springorm.sample.dao.PersonDao;
import org.reins.springorm.sample.entity.Person;
import org.reins.springorm.sample.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by chenhaopeng on 2019/5/2.
 */
@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonDao personDao;

    @Override
    public Person findPersonById(Integer id){
        return personDao.findOne(id);
    }

    public List<Person> findByAge(Integer age){return personDao.findByAge(age);}

}
